<div class="content-link flex grid-20">
    <div class="split">
        <a href="" class="total active">
            <h3>契約者総数</h3>
            <p class="num">25</p>
            <p>2月契約数：4回線 / 3月契約数：5回線</p>
        </a>
    </div>
    <div class="split">
        <a href="" class="genkai">
            <h3>契約者総数</h3>
            <p class="num">25</p>
            <p>2月契約数：4回線 / 3月契約数：5回線</p>
        </a>
    </div>
    <div class="split">
        <a href="" class="sim">
            <h3>契約者総数</h3>
            <p class="num">25</p>
            <p>2月契約数：4回線 / 3月契約数：5回線</p>
        </a>
    </div>
    <div class="split">
        <a href="" class="sugoi">
            <h3>契約者総数</h3>
            <p class="num">25</p>
            <p>2月契約数：4回線 / 3月契約数：5回線</p>
        </a>
    </div>
    <div class="split">
        <a href="" class="insentive">
            <h3>契約者総数</h3>
            <p class="num">25</p>
            <p>2月契約数：4回線 / 3月契約数：5回線</p>
        </a>
    </div>
</div>
