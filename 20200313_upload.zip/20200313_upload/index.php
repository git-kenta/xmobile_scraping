<?php
require_once('function.php');
$customers = customer();
$customer_details = customer_details(100029963);
?>
<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <title></title>
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/grid.css">
    <link rel="stylesheet" href="css/style.css">
    <!--[if lt IE 9]>
<script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
    <link rel="shortcut icon" href="">
</head>

<body>

    <!--↓header-->
    <header>
        <div class="flex header">
            <div class="header-left flex _center">
                <h1><img src="img/logo.png" alt="logo"></h1>
                <p>エックスモバイル契約状況</p>
            </div>
            <div class="header-right flex _column">
                <div class="header-right-top flex _middle _between">
                    <!--search insert-->
                    <div class="search">
                        <p>search</p>
                    </div>
                    <h3>最終更新日：2020年3月21日　16時15分</h3>
                </div>
                <div class="header-right-bottom flex _middle _between">
                    <h2>契約状況｜代理店名：株式会社ZUMI</h2>
                    <h3>インセンティブ、WEB在庫の金額・数量はおおよその目安です。</h3>
                </div>
            </div>
        </div>
    </header>
    <!--↑header-->
    <main>
        <div class="flex">
            <!--↓menu-->
            <div class="menu">
                <div class="menu-agency">
                    <div class="title flex _between">
                        <p>代理店</p>
                    </div>
                    <ul style="display: block">
                        <li class="active">全体</li>
                        <?php foreach($agencys as $agency):?>
                        <li><?= $agency['agency_name'];?></li>
                        <?php endforeach;?>
                    </ul>
                </div>
                <div class="menu-insentive">
                    <div class="title flex _between">
                        <p>インセンティブ</p><span>＋</span>
                    </div>
                    <ul>
                        <li><span class="name">株式会社ZUMI</span><span class="price">3,429円</span></li>
                        <li><span class="name">与那覇</span><span class="price">2,033円</span></li>
                        <li><span class="name">松川</span><span class="price">345円</span></li>
                    </ul>
                </div>
                <div class="menu-config">
                    <div class="title flex _between">
                        <p>設定</p><span>＋</span>
                    </div>
                    <ul>
                        <li>代理店追加・編集</li>
                        <li>WEB在庫設定</li>
                    </ul>
                </div>
            </div>
            <!--↑menu-->
            <!--↓content-->
            <div class="content">
                <!--↓content-link.php-->
<!--                <?php require_once('content-link.php');?>-->
                <!--↑content-link.php-->
                <!------------------------->

                <div class="content-list flex _between grid-20">

                    <!--↓content-list-all.php-->
                    <?php require_once('content-list-all.php');?>
                    <!--↑content-list-all.php-->

                    <!--↓content-list-one.php-->
                    <?php require_once('content-list-one.php');?>
                    <!--↑content-list-one.php-->

                </div>
            </div>
            <!--↑content-->
        </div>
    </main>

    <script src="js/jquery-3.4.1.min.js"></script>
    <script src="js/main.js"></script>
</body>

</html>
