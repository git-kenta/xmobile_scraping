$(function () {
    $(document).on('click', '.menu-agency li', function () {
        var index = $('.menu-agency li').index(this);
        $('.menu-agency li').removeClass('active');
        $(this).addClass('active');
    });
});
