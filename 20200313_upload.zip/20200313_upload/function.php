<?php
require_once('db.php');
$sort_check = '';
//---------------------------------------------【関数】
/*全表示*/
function show_all($i,$s = null) {
    extract($GLOBALS);
    $stmt = $db -> prepare($i);
    $stmt -> execute($s);
    return $stmt -> fetchall(PDO::FETCH_ASSOC);
}
//表示
function show($i,$s = null) {
    extract($GLOBALS);
    $stmt = $db -> prepare($i);
    $stmt -> execute($s);
    return $stmt -> fetch(PDO::FETCH_ASSOC);
}
//データの削除・更新・追加
function other_db($i,$s = null) {
    extract($GLOBALS);        
    $stmt = $db->prepare($i);
    return $stmt -> execute($s);
}
//三桁区切り
function price_format($price) {
    return number_format($price);
}

/* 暗号化関数 */
function saltango($password, $salt) {
    $saltPassword = crypt($password, $salt);
    return $saltPassword;
}

/* ランダムな文字列を生成 */
function mksalt($length = 8) {
    return substr(str_shuffle(str_repeat('0123456789abcdefghijklmnopqrstuvwxyz', $length)), 0, $length);
}
//--------------------------------------------------
function customer() {
    return show_all("
    select * from customer 
    left join plan on customer.plan_number = plan.plan_number
    left join agency on customer.agency_id = agency.agency_id order by customer.contract_date asc");
}

function customer_details($vl) {
    return show("
    select * from customer
    left join plan on customer.plan_number = plan.plan_number
    left join agency on customer.agency_id = agency.agency_id
    left join agreement on customer.agreement = agreement.agreement_id
    where customer.number = {$vl}");
}
//-----
function agencys() {
    return show_all("select * from agency");}
$agencys = agencys();




//$customers = customer();
/*----------------------------------------------------------------スタッフ*/
//function staff() {return show_all("select * from staff");}
//$staffs = staff();
///*----------------------------------------------------------------媒体*/
//function medium() {return show_all("select * from mediums");}
//$mediums = medium();
///*----------------------------------------------------------------支払い方法*/
//function payment() {return show_all("select * from payment");}
//$payments = payment();
///*----------------------------------------------------------------ステータス*/
//function status() {return show_all("select * from statuss");}
//$statuss = status();
///*----------------------------------------------------------------お客様*/
//function customer() {return show_all("select * from customer");}
//$customers = customer();
///*----------------------------------------------------------------メニュー（一覧）*/
//function menu() {return show_all("select * from menu");}
//$menus = menu();
///*----------------------------------------------------------------メニュー（種別あり）*/
//function list_menu() {return show_all("select menu.id,menu.name,menu.operation,menu.price,service.name as 'service' from menu left join service on service.id = menu.service_id");}
//$list_menu = list_menu();
///*----------------------------------------------------------------目標金額*/
//function list_goal() {return show("select price from goal");}
//$list_goal = list_goal();
///*----------------------------------------------------------------休日*/
//function list_holiday() {return show_all("select * from holiday where holiday = 1");}
//global $list_holiday;
//$list_holiday = list_holiday();
///*----------------------------------------------------------------休日(全部)*/
//function list_holiday_all() {return show_all("select * from holiday");}
//$list_holiday_all = list_holiday_all();
///*----------------------------------------------------------------売上件数*/
//function sales_count() {
//    $sales_number = show("select count(id) as 'count' from sales;");
//    return $sales_number['count'];
//}
//$sales_count = sales_count();
///*----------------------------------------------------------------役務*/
//function list_service() {return show_all("select * from service");}
//$list_service = list_service();

/*----------------------------------------------------------------お客様一覧*/
//function list_customer() {
//    return show_all("
//select
//    id,
//    name,
//    date_format(birthday,'%Y年%m月%d日') as 'birthday',
//    TIMESTAMPDIFF(YEAR, `birthday`, CURDATE()) AS age
//from customer;
//");
//}
//$list_customer = list_customer();
//
///*----------------------------------------------------------------残日数*/
//function day_count() {
//    global $list_holiday;
//    $count = count($list_holiday);
//$num = 1;
//$code = "SELECT DATEDIFF(last_day(curdate()),now()) + 1
//-(
//select ";
//foreach($list_holiday as $value) {
//    if($count == $num) {
//        $code .= "floor( ( datediff(last_day(curdate()),now()) + 1 ) / 7 )+case when instr(substring('12345671234567', dayofweek(now()), mod( datediff(last_day(curdate()),now()) + 1 , 7)),{$value['id']}) > 0 then 1 else 0 end";
//    } else {
//        $code .= "floor( ( datediff(last_day(curdate()),now()) + 1 ) / 7 )+case when instr(substring('12345671234567', dayofweek(now()), mod( datediff(last_day(curdate()),now()) + 1 , 7)),{$value['id']}) > 0 then 1 else 0 end + ";
//    }
//    $num++;
//}
//$code .= ") as 'days';";
//$day_count = show($code);
//return $day_count['days'];
//}
//$day_count = day_count();

/*----------------------------------------------------------------当月売上データ*/
//function analysis_thisMonth() {
//    return show("
//select
//    sum(case when menu.service_id = 1 then sales_menu.price * sales_menu.num end) as 'yakumu',
//    sum(case when menu.service_id = 2 then sales_menu.price * sales_menu.num end) as 'buppan',
//    sum(case when menu.service_id = 3 then sales_menu.price * sales_menu.num end) as 'option',
//    sum(sales_menu.price * sales_menu.num) as 'calc',
//    (select count(case when sales.status_id = 1 then status_id end) from sales where sales_date like date_format(now(),'%Y-%m%')) as 'new',
//    (select count(case when sales.status_id = 2 then status_id end) from sales where sales_date like date_format(now(),'%Y-%m%')) as 'old',
//    sum(sales_menu.price * sales_menu.num) / (select count(id) from sales where sales_date like date_format(now(),'%Y-%m%')) as 'avg',
//    (select sum(point) from sales where sales_date like date_format(now(),'%Y-%m%')) as 'point'
//from sales
//    left join sales_menu on sales_menu.sales_id = sales.id
//    left join menu on menu.id = sales_menu.menu_id
//where
//    sales_date like date_format(now(),'%Y-%m%');        
//");
//}
//$analysis_thisMonth = analysis_thisMonth();
//
///*----------------------------------------------------------------本日売上データ*/
//function analysis_today() {
//    return show("
//    select
//    sum(case when menu.service_id = 1 then sales_menu.price * sales_menu.num end) as 'yakumu',
//    sum(case when menu.service_id = 2 then sales_menu.price * sales_menu.num end) as 'buppan',
//    sum(case when menu.service_id = 3 then sales_menu.price * sales_menu.num end) as 'option',
//    sum(sales_menu.price * sales_menu.num) as 'calc',
//    (select count(case when sales.status_id = 1 then status_id end) from sales where sales_date like date_format(now(),'%Y-%m-%d%')) as 'new',
//    (select count(case when sales.status_id = 2 then status_id end) from sales where sales_date like date_format(now(),'%Y-%m-%d%')) as 'old',
//    sum(sales_menu.price * sales_menu.num) / (select count(id) from sales where sales_date like date_format(now(),'%Y-%m-%d%')) as 'avg',
//    (select sum(point) from sales where sales_date like date_format(now(),'%Y-%m-%d%')) as 'point'
//from sales
//    left join sales_menu on sales_menu.sales_id = sales.id
//    left join menu on menu.id = sales_menu.menu_id
//where
//    sales_date like date_format(now(),'%Y-%m-%d%');
//");
//}
//$analysis_today = analysis_today();
//
//
//
///*日付摘出*/
//$sort_day = show_all("
//    select distinct date_format(sales_date,'%Y-%m') as month_num,date_format(sales_date,'%Y年%m月') as month from sales order by month;
//");


/*------------------------------------

        分析関連(analysis)

------------------------------------*/
/*----------------------------------------------------------------売上データ*/
//function analysis_data($code="sales_date like date_format(now(),'%Y-%m%')",$order="date desc") {
//    return show_all("
//   select
//        sales.id as 'id_number',
//        statuss.name as 'status_name',
//        date_format(sales.sales_date,'%Y年%m月%d日') as 'date',
//        staff.name as 'staff_name',
//        customer.name as 'customer_name',
//        sum(sales_menu.price * sales_menu.num) as 'calc',
//        sales.memo as 'memo',
//        max(sales_menu.name) as 'menu_name'
//    from sales
//        left join sales_menu on sales_menu.sales_id = sales.id
//        left join statuss on statuss.id = sales.status_id
//        left join staff on staff.id = sales.staff_id
//        left join customer on customer.id = sales.customer_id
//    where
//        {$code}
//    group by 
//        id_number
//    order by 
//        {$order};
//");
//}
//$analysis_data = analysis_data();
//
//
//
///*媒体*/
//function analysis_medium($code="sales_date like date_format(now(),'%Y-%m%')") {
//    return show_all("
//    select
//        mediums.name as 'name',
//        sum(sales_menu.price * sales_menu.num) as 'calc',
//        count(distinct case when status_id = 1 then sales.id end) as 'new',
//        count(distinct case when status_id = 2 then sales.id end) as 'old',
//        count(distinct sales.id) as 'all'
//    from mediums
//        left join sales on sales.medium_id = mediums.id
//        left join sales_menu on sales_menu.sales_id = sales.id
//    where
//        {$code}
//    group by 
//        mediums.id
//    order by calc desc;
//");
//}
//$analysis_mediums = analysis_medium();
//
//
//
///*スタッフ分析*/
//function analysis_staff($code="sales_date like date_format(now(),'%Y-%m%')") {
//    return show_all("
//    select
//        staff.name as 'name',
//        staff.yomi as yomi,
//        count(distinct sales.id) as customer_num,
//        sum(sales_menu.price * sales_menu.num) as 'calc',
//        sum(case when service.id = 1 then sales_menu.price * sales_menu.num end) as 'yakumu',
//        sum(case when service.id = 2 then sales_menu.price * sales_menu.num end) as 'buppan',
//        sum(case when service.id = 3 then sales_menu.price * sales_menu.num end) as 'option'
//    from staff
//        left join sales on sales.staff_id = staff.id
//        left join sales_menu on sales_menu.sales_id = sales.id
//        left join menu on menu.id = sales_menu.menu_id
//        left join service on service.id = menu.service_id
//    where
//        {$code}
//    group by
//        staff.id;
//");
//}
//$analysis_staff = analysis_staff();
//
//
///*メニュー分析*/
//function analysis_menu($code="sales_date like date_format(now(),'%Y-%m%')") {
//    return show_all("
//    select
//        menu.name as 'name',
//        count(menu_id) as 'num',
//        sum(sales_menu.price * sales_menu.num) as 'calc'
//    from menu
//        left join sales_menu on sales_menu.menu_id = menu.id
//        left join sales on sales.id = sales_menu.sales_id
//    where
//        {$code}
//    group by 
//        menu.name
//    having
//        count(menu_id) != 0
//    order by
//        sum(sales_menu.price * sales_menu.num) desc;
//");
//}
//$analysis_menu = analysis_menu();
//
//
///*月別分析*/
//function analysis_month($code="sales_date like date_format(now(),'%Y-%m%')") {
//    return show_all("
//    select
//        date_format(sales.sales_date,'%Y年%m月') as 'date',
//        sum(sales_menu.price * sales_menu.num) as 'calc',
//        sum(case when menu.service_id = 1 then sales_menu.price * sales_menu.num end) as 'yakumu',
//        sum(case when menu.service_id = 2 then sales_menu.price * sales_menu.num end) as 'buppan',
//        sum(case when menu.service_id = 3 then sales_menu.price * sales_menu.num end) as 'option',
//        count(distinct sales.id) as 'num'
//    from sales
//        left join sales_menu on sales_menu.sales_id = sales.id
//        left join menu on menu.id = sales_menu.menu_id
//    where
//        {$code}
//    group by
//        date_format(sales.sales_date,'%Y年%m月');
//");
//}
//$analysis_month = analysis_month();


/*------------------------------------

                ポップ関連

------------------------------------*/
