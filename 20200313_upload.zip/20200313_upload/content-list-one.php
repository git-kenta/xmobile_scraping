<div class="content-list-one">
    <div class="split">
        <h3 class="title">契約者情報</h3>
        <div class="content-list-box">
            <table>
                <tr class="flex">
                    <td class="flex _between">
                        <span>お客様名</span>
                        <p><?= $customer_details['name'];?></p>
                    </td>
                    <td class="flex _between">
                        <span>よみがな</span>
                        <p><?= $customer_details['yomi'];?></p>
                    </td>
                </tr>
                <tr class="flex">
                    <td class="flex _between">
                        <span>電話番号</span>
                        <p><?= $customer_details['phone'];?></p>
                    </td>
                    <td class="flex _between">
                        <span>メールアドレス</span>
                        <p><?= $customer_details['mail'];?></p>
                    </td>
                </tr>
                <tr class="flex">
                    <td class="flex _between" colspan="2">
                        <span>住所</span>
                        <p><?= $customer_details['address'];?></p>
                    </td>
                </tr>
            </table>
            <hr>
            <table>
                <tr class="flex">
                    <td class="flex _between">
                        <span>プラン</span>
                        <p><?= $customer_details['plan_name'];?></p>
                    </td>
                    <td class="flex _between">
                        <span>契約日</span>
                        <p><?= date('Y年m月d日',strtotime($customer['contract_date']));?></p>
                    </td>
                </tr>
                <tr class="flex">
                    <td class="flex _between">
                        <span>月額料金</span>
                        <p>
                            <?php 
                                                $price = price_format($customer_details['price']);
                                                if ($price == 0) {
                                                    echo '- 円';
                                                } else {
                                                    echo $price.'円';
                                                }
                                                ;?>
                        </p>
                    </td>
                    <td class="flex _between">
                        <span>インセンティブ</span>
                        <p>con</p>
                    </td>
                </tr>
                <tr class="flex">
                    <td class="flex _between">
                        <span>代理店</span>
                        <p><?= $customer_details['agency_name'];?></p>
                    </td>
                    <td class="flex _between">
                        <span>契約種別</span>
                        <p><?= $customer_details['agreement_name'];?></p>
                    </td>
                </tr>
                <tr class="flex">
                    <td class="flex _between" colspan="2">
                        <span>プラン詳細</span>
                        <p><?= $customer_details['plan_details'];?></p>
                    </td>
                </tr>
                <tr class="flex">
                    <td class="flex _between" colspan="2">
                        <span>メモ</span>
                        <p></p>
                    </td>
                </tr>
            </table>


        </div>
    </div>
</div>
